package cz.example.pripojsenaserver;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.Properties;

import android.app.Activity;
import android.os.Bundle;
import android.view.Menu;
import android.view.View;
import android.widget.EditText;

public class PripojTo extends Activity {

	@Override
	protected void onCreate(Bundle savedInstanceState) {
		super.onCreate(savedInstanceState);
		setContentView(R.layout.activity_pripoj_to);
	}

	@Override
	public boolean onCreateOptionsMenu(Menu menu) {
		// Inflate the menu; this adds items to the action bar if it is present.
		getMenuInflater().inflate(R.menu.pripoj_to, menu);
		return true;
	}
	public void Poslani(View v)
	{
		
		
		EditText editT=(EditText) findViewById(R.id.editText1);
		String message=editT.getText().toString();
		System.out.println("Checking if Driver is registered with DriverManager.");
		  
		  try {
		    Class.forName("org.postgresql.Driver");
		  } catch (ClassNotFoundException cnfe) {
		    System.out.println("Couldn't find the driver!");
		    System.out.println("Let's print a stack trace, and exit.");
		    cnfe.printStackTrace();
		    System.exit(1);
		  }
		  
		  System.out.println("Registered the driver ok, so let's make a connection.");
		  
		  Connection c = null;
		  
		  try {
		    // The second and third arguments are the username and password,
		    // respectively. They should be whatever is necessary to connect
		    // to the database.
		    //c = DriverManager.getConnection("jdbc:postgresql://geo102.fsv.cvut.cz/pin2_b13",
		                               //     "pin2_b13", "skupinaB");
		    String url = "jdbc:postgresql://geo102.fsv.cvut.cz/pin2_b13";
			Properties props = new Properties();
			props.setProperty("user", "pin2_b13");
			props.setProperty("password", "skupinaB");
			//props.setProperty("ssl", "true");
			c = DriverManager.getConnection(url, props);
			Statement st = c.createStatement();
			st.execute("INSERT INTO pokus1(jmeno) VALUES ('pokuss')");
			st.close();
			c.close();
		  } catch (SQLException se) {
		    System.out.println("Couldn't connect: print out a stack trace and exit.");
		    se.printStackTrace();
		    System.exit(1);
		  }
		  
		  if (c != null)
		    System.out.println("Hooray! We connected to the database!");
		  else
		    System.out.println("We should never get here.");
	}

}
